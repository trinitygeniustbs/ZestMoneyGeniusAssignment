package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import TestBase.testBase;

public class AmazonPage extends testBase{
	
	@FindBy(xpath = "//input[@id='twotabsearchtextbox']")
	public WebElement searchbox;
	
	@FindBy(xpath = "//input[@type='submit'][1]")
	public WebElement submit;

	@FindBy(xpath = "//img[@alt='Apple iPhone XR (64GB) - Yellow']")
	public WebElement image;
	
	@FindBy(xpath = "//span[@id='priceblock_ourprice']")
	public WebElement price;
	

	public AmazonPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);	
	}


	
	
}
