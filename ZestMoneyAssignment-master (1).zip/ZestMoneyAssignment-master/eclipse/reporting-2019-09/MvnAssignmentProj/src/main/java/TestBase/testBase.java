package TestBase;

import java.io.FileInputStream;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class testBase {
	
	public static WebDriver driver;
	public Properties prop;
	
	
	public testBase() {
		
		prop = new Properties();

		try {
			FileInputStream fis = new FileInputStream("/Users/pretty.sanwale/eclipse/reporting-2019-09/MvnAssignmentProj/src/main/java/configFiles/config.properties");
			prop.load(fis);
			
		} catch( Exception e) {
			
			e.printStackTrace();	
		}
			
		
	}
	
	public void initialize() {
		
		String browsername = prop.getProperty("browser");
	
		if(browsername.equals("chrome")) {
		
		   System.setProperty("webdriver.chrome.driver","/Users/pretty.sanwale/git/PagefactoryTest/SeleniumTestNg/chromedriver");
		   driver = new ChromeDriver();	
		   
		}else {
			
			System.setProperty("webdriver.gecko.driver","put the path of firefox driver.exe file");
			   driver = new FirefoxDriver();	
		}
		
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.manage().timeouts().pageLoadTimeout(50, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);	
	      	
	}

}
