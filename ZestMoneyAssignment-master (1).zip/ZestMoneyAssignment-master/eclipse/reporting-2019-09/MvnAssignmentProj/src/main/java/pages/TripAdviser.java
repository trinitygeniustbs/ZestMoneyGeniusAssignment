package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import TestBase.testBase;

public class TripAdviser extends testBase{
	
	@FindBy(xpath="//span[text()='Search']")
	public WebElement initiateSearch;
	
	@FindBy(xpath = "//input[@title='Search']")
	public WebElement search2;
	
	@FindBy(xpath = "//*[@id='mainSearch']")
	public WebElement mainSearch;
	
	@FindBy(xpath = "//button[@title='Search']")
	public WebElement submit2;
	
	@FindBy(id = "SEARCH_BUTTON_CONTENT")
	public WebElement searchButton;

	@FindBy(xpath = "(//div[@data-widget-type='TOP_RESULT'])[2]")
	public WebElement firstResult;
	
	@FindBy(xpath = "//a[text()='Write a review']")
	public WebElement WriteReview;
	
	@FindBy(xpath = "//*[@id='bubble_rating']")
	public WebElement bubbleRating;
	
	@FindBy(xpath = "//input[@id='ReviewTitle']")
	public WebElement ReviewTitel;
	
	@FindBy(xpath = "//textarea[@name='ReviewText']")
	public WebElement ReviewText;
	
	@FindBy(xpath = "//*[@data-error='REVIEW_TITLE_PROFANITY']")
	public WebElement REVIEW_TITLE_PROFANITY;
	
	@FindBy(xpath = "//*[@data-error='REVIEW_TEXT_ALL_CAPS']")
	public WebElement REVIEW_TEXT_ALL_CAPS;
	
	@FindBy(xpath = "//*[@data-error='REVIEW_TEXT_TOO_SHORT']")
	public WebElement REVIEW_TEXT_TOO_SHORT;
	
	@FindBy(xpath = "//*[@data-error='REVIEW_TEXT_TOO_LONG']")
	public WebElement REVIEW_TEXT_TOO_LONG;
	
	@FindBy(xpath="//*[@data-category='Business']")
	public WebElement Business;
	
	@FindBy(xpath="//*[@data-category='withSpouse']")
	public WebElement withSpouse;
	
	@FindBy(xpath="//*[@data-category='familyYoungChildren']")
	public WebElement familyYoungChildren;
	
	@FindBy(xpath="//*[@data-category='withFriends']")
	public WebElement withFriends;
	
	@FindBy(xpath="//*[@data-category='soloTraveler']")
	public WebElement soloTraveler;
	
	@FindBy(id= "trip_date_month_year")
	public WebElement travelDateDropDown;
	
	@FindBy(xpath="//span[@id='qid12_bubbles']")
	public WebElement serviceRating;
	
	@FindBy(xpath="//span[@id='qid47_bubbles']")
	public WebElement locationRating;
	
	@FindBy(xpath="//span[@id='qid14_bubbles']")
	public WebElement cleanlinessRating;
	
	@FindBy(xpath="//*[@id='noFraud']")
	public WebElement agreementCheck;
	
	@FindBy(xpath="//*[@id='SUBMIT'] ")
	public WebElement Submit;
	
	@FindBy(xpath="//*[@alt='Tripadvisor']")
	public WebElement loginPopup;

	
    public TripAdviser(WebDriver driver){      
		this.driver = driver;
		PageFactory.initElements(driver, this);	
	}
    
    public void selectCategory(String category) {
    	
    	  if(category.equalsIgnoreCase("Business")){
    		   Business.click();	  
    	  }else if(category.equalsIgnoreCase("withSpouse")) {  
    		  withSpouse.click();
    	  }else if(category.equalsIgnoreCase("familyYoungChildren")){
    		  familyYoungChildren.click();
    	  }else if(category.equalsIgnoreCase("withFriends")){
    		  withFriends.click();
    	  }else if(category.equalsIgnoreCase("soloTraveler")){
    		  soloTraveler.click();
    	  }else {
    		  System.out.println("No category provided");
    	  }
    }

}
