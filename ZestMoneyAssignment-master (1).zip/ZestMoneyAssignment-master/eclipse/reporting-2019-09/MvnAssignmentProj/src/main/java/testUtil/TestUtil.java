package testUtil;



import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import TestBase.testBase;


public class TestUtil extends testBase{
	
	public WebElement elem;
	public boolean flag;

    public void switchToChildWindow(){	
	  for(String childWindow:driver.getWindowHandles()){
		  driver.switchTo().window(childWindow);
		 }
	 }
    
    public void flipkartpopuphandle() {
       try {
	         driver.findElement(By.xpath("//button[@class='_2AkmmA _29YdH8']")).click();
	      }catch(Exception e){}  
    }
    
    public void alerhandle() {
        try {
         	driver.switchTo().alert().dismiss();
 	      }catch(Exception e){}  
     }
    
    public void priceComparision(int AmazonPrice, int FlipkartPrice) {
    	 
    	 if(AmazonPrice>FlipkartPrice){
    		System.out.println("FlipkartPrice is less " + FlipkartPrice);
    	  }else {
    		  System.out.println("AmazonPrice is less " + AmazonPrice);
        }
    }
    
    public void mouseHoverToElement(WebElement elem){
    	  Actions action = new Actions(driver);
    	  action.moveToElement(elem).click().build().perform();;  	  
    }
    
    public void alertdismiss() {
    	try {
    	driver.switchTo().alert().dismiss();
    	}catch(Exception e) {}
    }
    
    public void selectTravelDate(WebElement elem, String Option) {
     Select select = new Select(elem);
    	 select.selectByVisibleText(Option);
    }
    
    public void selectCheckBox(WebElement elem) {
    	  flag=elem.isSelected();
    	  if(flag == false) {
    		elem.click();
    	  }else{
    		System.out.println("checkbox is already selected");
    	  }
    	
    }
    
 }	 
		
		
	
	
	


