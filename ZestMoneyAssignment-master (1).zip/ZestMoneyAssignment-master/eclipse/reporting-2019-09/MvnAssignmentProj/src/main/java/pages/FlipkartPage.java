package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import TestBase.testBase;

public class FlipkartPage extends testBase{
	

	@FindBy(xpath = "//input[@title='Search for products, brands and more']")
	public WebElement searchbox;
	
	@FindBy(xpath = "//button[@type='submit']")
	public WebElement submit;

	@FindBy(xpath = "//img[@alt='Apple iPhone XR (Yellow, 64 GB)']")
	public WebElement image;
	
	@FindBy(xpath = "//div[@class='_1vC4OE _3qQ9m1']")
	public WebElement price;
	
    public FlipkartPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);	
	}


}
