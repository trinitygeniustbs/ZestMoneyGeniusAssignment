package testcase;

import static org.testng.Assert.assertTrue;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import pages.TripAdviser;
import testUtil.TestUtil;

public class Assignment2 extends TestUtil{
	
	public static TripAdviser tripobj = new TripAdviser(driver);
	
	@BeforeClass
	  public void setUp() {
		  initialize();
		  PageFactory.initElements(driver, tripobj);
		 
	  }
	
	@Test(priority=1)
	public void TripAdviser() {
		  driver.get(prop.getProperty("TripAdviserurl"));
		  String trip = prop.getProperty("searchTrip");
		  
		  try{
		       tripobj.initiateSearch.click();
		       tripobj.mainSearch.sendKeys(trip); 
		       tripobj.searchButton.click(); 
		  }catch(Exception e ){
			 tripobj.search2.sendKeys(trip);	
			 tripobj.submit2.click();
		  }
		  tripobj.firstResult.click(); 	  
	}
	
	@Test(priority=2)
	public void writeReview(){
		switchToChildWindow();
		alertdismiss();
		tripobj.WriteReview.click();
		switchToChildWindow();
					
	}
	
	@Test(priority=3)
	public void enterReviewDetais(){
		tripobj.ReviewTitel.sendKeys(prop.getProperty("ReviewTitel"));
		tripobj.ReviewText.sendKeys(prop.getProperty("ReviewText"));
		tripobj.selectCategory(prop.getProperty("category"));
		alertdismiss();
		selectTravelDate(tripobj.travelDateDropDown, prop.getProperty("TravelDate"));
	}
	
	@Test(priority=4)
	public void enterBubbleRating(){   
		mouseHoverToElement(tripobj.bubbleRating);
		mouseHoverToElement(tripobj.locationRating);
		mouseHoverToElement(tripobj.cleanlinessRating);
		mouseHoverToElement(tripobj.serviceRating);
	}
	
	@Test(priority=5)
	public void finelReviewSubmit(){
		selectCheckBox(tripobj.agreementCheck);	
		tripobj.Submit.click();
		driver.switchTo().frame(0);
		assertTrue(tripobj.loginPopup.isDisplayed());
	}
	
	@AfterClass
	public void tearDown() {	
		driver.quit();
	}


}
