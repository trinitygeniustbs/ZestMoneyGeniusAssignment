package testcase;

import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import pages.AmazonPage;
import pages.FlipkartPage;
import testUtil.TestUtil;

public class Assignment1 extends TestUtil{
	
	public static AmazonPage object = new AmazonPage(driver);
	public static FlipkartPage flipkartobj = new FlipkartPage(driver);
	int AmazonPrice;
	int FlipkartPrice;
	
  @BeforeTest
  public void setUp() {
	  initialize();
	  PageFactory.initElements(driver, object);
	  PageFactory.initElements(driver, flipkartobj);
  }
  
  @Test(priority=1)
  public void amazonTest(){
	  
	    driver.get(prop.getProperty("Amazonurl"));
		String item = prop.getProperty("ItemToSearch");
		object.searchbox.sendKeys(item);
		object.submit.click();
		object.image.isDisplayed();
	    object.image.click();
	    switchToChildWindow();
	    String price = object.price.getText();
	    String actualprice = price.replaceAll("[ ₹,]", "");
	    double Price = Double.parseDouble(actualprice); 
	    AmazonPrice = (int)Price;	  
  }
  
  @Test(priority=2)
  public void flipkartTest(){
	 	driver.get(prop.getProperty("Flipkarturl"));
		String item = prop.getProperty("ItemToSearch");
		alerhandle();
		flipkartpopuphandle();
		flipkartobj.searchbox.sendKeys(item);
		flipkartobj.submit.click();
		flipkartobj.image.isDisplayed();
		flipkartobj.image.click();
	    switchToChildWindow();
	    String price = flipkartobj.price.getText();
	    String actualprice = price.replaceAll("[₹,]", "");
	    FlipkartPrice = Integer.parseInt(actualprice); 
	    priceComparision(AmazonPrice,FlipkartPrice);	
  }
  
  @AfterTest
  public void tearDown() {
	  driver.quit();
  }
	

}
